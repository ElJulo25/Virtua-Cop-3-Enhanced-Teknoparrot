Reshade Presets for Virtua Cop 3 on Teknoparrot By ElJulo

I tried to make the game less "blueish" and delete some persistants shadows to a more pleasant Journey on this 
amazing game. I recommend VC3 ENHANCED for best experience.. But all presets are playable
Good game to everyone.

INSTALLATION
--------------

1. Head to Reshade.me - download the latest version of Reshade.
2. Open and install Reshade to your \TEKNOPARROT\cxbxr Folder. This will be where cxbx.exe is for The game. Select DIRECT X 9
3. When it asks about which FX to install, simply hit Uncheck all then hit When it asks about which FX to install, simply hit Standard effects, sweetFX by Ceejay, Legacy effects and FXShaders by luluco250, and install (IMPORTANT), and install. (IMPORTANT)

4. Place the preset files "VC3 ENHANCED by ElJulo " (.ini) in this .zip within the cbxr root folder, this is where your .exe resides. (also as reshade shaders)
4. Launch the game, hit your HOME button, or "DEBUT" in french (just upper "END") and you should be able to see your Reshade menu.
5. From here, you can head to a dropdown menu at the very top, browse and find the file "VC3 ENHANCED by ElJulo ", double click, select your presets.
6. Press "HOME" or "DEBUT" to close reShade.



